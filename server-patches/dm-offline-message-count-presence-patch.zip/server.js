
const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const net = require("net");

const app = express();
const PORT = Number(process.env.PORT || 8787);

// 저장 폴더
const MEDIA_DIR = path.join(__dirname, "media");
const IMAGE_DIR = path.join(MEDIA_DIR, "image");
const VOICE_DIR = path.join(MEDIA_DIR, "voice");
const VIDEO_DIR = path.join(MEDIA_DIR, "video");

const MESSAGE_DIR = path.join(__dirname, "messages");
const MESSAGE_FILE = path.join(MESSAGE_DIR, "messages.json");
const MESSAGE_SEQUENCE_FILE = path.join(MESSAGE_DIR, "message-sequence.json");
const LEGACY_MESSAGE_FILE = path.join(__dirname, "messages.json");
const ACCOUNT_FILE = path.join(__dirname, "accounts.json");
const PROFILE_FILE = path.join(__dirname, "profiles.json");
const BLOCKED_FANS_FILE = path.join(__dirname, "blocked-fans.json");
const LEGACY_MEMBER_FILE = path.join(__dirname, "members.json");
const SERVER_CONFIG_FILE = path.join(__dirname, "server-config.json");
const SESSION_FILE = path.join(__dirname, "sessions.json");
const OFFLINE_MESSAGE_COUNT_FILE = path.join(__dirname, "offline-message-counts.json");
const MEDIA_SIGNING_KEY_FILE = path.join(__dirname, "media-signing.key");

// 하위 폴더 자동 생성
[IMAGE_DIR, VOICE_DIR, VIDEO_DIR, MESSAGE_DIR].forEach((dir) => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
});

// 미들웨어
app.use((req, res, next) => {
    if (req.headers["access-control-request-private-network"] === "true") {
        res.setHeader("Access-Control-Allow-Private-Network", "true");
    }
    next();
});
app.use(cors());
app.use(express.json({ limit: "2mb" }));

const MEDIA_FOLDERS = { image: IMAGE_DIR, audio: VOICE_DIR, video: VIDEO_DIR };
const folderForType = (type) => type === "audio" ? "voice" : type;
function uploadMediaType(req, file) {
    const mimeType = file.mimetype || req.body?.mimeType || "";
    const detected = mimeType.startsWith("image/") ? "image" : mimeType.startsWith("video/") ? "video" : mimeType.startsWith("audio/") ? "audio" : null;
    const requested = ["image", "audio", "video"].includes(req.body?.mediaType) ? req.body.mediaType : null;
    if (!detected) return null;
    if (requested === detected) return requested;
    if ((requested === "audio" || requested === "video") && (detected === "audio" || detected === "video") && /^(audio|video)\/mp4$/i.test(mimeType)) return requested;
    return detected;
}
function canonicalMediaUrl(value, preferredType) {
    if (typeof value !== "string" || /^(data:|blob:|file:)/i.test(value)) return value;
    let pathname;
    try { pathname = new URL(value, "http://media.local").pathname; }
    catch { return value; }
    const marker = "/media/";
    const markerIndex = pathname.indexOf(marker);
    if (markerIndex < 0) return value;
    const fileName = path.basename(pathname);
    if (!fileName || fileName === "." || fileName === "/") return value;
    const physicalFolder = Object.entries(MEDIA_FOLDERS).find(([, folder]) => fs.existsSync(path.join(folder, fileName)));
    const currentFolder = pathname.slice(markerIndex + marker.length).split("/").filter(Boolean)[0];
    const knownFolders = new Set(["image", "voice", "video"]);
    const folder = physicalFolder
        ? path.basename(physicalFolder[1])
        : knownFolders.has(currentFolder)
            ? currentFolder
            : folderForType(preferredType);
    if (!knownFolders.has(folder)) return value;
    return `/media/${folder}/${fileName}`;
}

function normalizeMessageMediaPaths(message) {
    if (!message || typeof message !== "object") return message;
    const normalized = { ...message };
    if (typeof normalized.imageUri === "string") normalized.imageUri = canonicalMediaUrl(normalized.imageUri, "image");
    if (Array.isArray(normalized.imageUris)) normalized.imageUris = normalized.imageUris.map((url) => canonicalMediaUrl(url, "image"));
    if (Array.isArray(normalized.media)) normalized.media = normalized.media.map((item) => item && typeof item === "object"
        ? { ...item, url: canonicalMediaUrl(item.url, item.mediaType) }
        : item);
    return normalized;
}

// 메시지 파일 읽기
async function loadMessages() {
    try {
        if (!fs.existsSync(MESSAGE_FILE)) {
            if (!fs.existsSync(LEGACY_MESSAGE_FILE)) return [];
            const legacyBackup = `${LEGACY_MESSAGE_FILE}.backup-before-migration`;
            if (!fs.existsSync(legacyBackup)) await fs.promises.copyFile(LEGACY_MESSAGE_FILE, legacyBackup);
            const migrated = await fs.promises.readFile(LEGACY_MESSAGE_FILE, "utf8");
            const tempFile = `${MESSAGE_FILE}.tmp`;
            await fs.promises.writeFile(tempFile, migrated, "utf8");
            await fs.promises.rename(tempFile, MESSAGE_FILE);
        }

        const data = await fs.promises.readFile(MESSAGE_FILE, "utf8");
        const original = JSON.parse(data);
        const normalized = original.map(normalizeMessageMediaPaths);
        if (JSON.stringify(original) !== JSON.stringify(normalized)) await saveMessages(normalized);
        return normalized;

    } catch (error) {
        console.error("메시지 읽기 오류:", error);
        throw error;
    }
}

// 메시지 파일 저장
async function saveMessages(messages) {
    const tempFile = `${MESSAGE_FILE}.tmp`;
    await fs.promises.writeFile(tempFile, JSON.stringify(messages, null, 2), "utf8");
    await fs.promises.rename(tempFile, MESSAGE_FILE);
}

let messageSequenceQueue = Promise.resolve();

async function readMessageCursor(messages) {
    let storedNext = 1;
    try {
        const value = JSON.parse(await fs.promises.readFile(MESSAGE_SEQUENCE_FILE, "utf8"));
        if (Number.isSafeInteger(value?.nextSequence) && value.nextSequence > 0) storedNext = value.nextSequence;
    } catch { /* first cursor allocation */ }
    const maximum = messages.reduce((current, message) => Number.isSafeInteger(message?.serverSequence) ? Math.max(current, message.serverSequence) : current, 0);
    return Math.max(maximum + 1, storedNext);
}

async function issueMessageSequence(messages) {
    const allocate = messageSequenceQueue.then(async () => {
        const nextSequence = await readMessageCursor(messages);
        const tempFile = `${MESSAGE_SEQUENCE_FILE}.tmp`;
        await fs.promises.writeFile(tempFile, JSON.stringify({ nextSequence: nextSequence + 1 }, null, 2), "utf8");
        await fs.promises.rename(tempFile, MESSAGE_SEQUENCE_FILE);
        return nextSequence;
    });
    messageSequenceQueue = allocate.catch(() => undefined);
    return allocate;
}

const messageCursor = (messages) => messages.reduce((current, message) => Number.isSafeInteger(message?.serverSequence) ? Math.max(current, message.serverSequence) : current, 0);

async function loadAccounts() {
    try {
        if (!fs.existsSync(ACCOUNT_FILE)) return [];
        const original = JSON.parse(await fs.promises.readFile(ACCOUNT_FILE, "utf8"));
        const normalized = original.map((account) => account && typeof account.avatarUri === "string"
            ? { ...account, avatarUri: canonicalMediaUrl(account.avatarUri, "image") }
            : account);
        if (JSON.stringify(original) !== JSON.stringify(normalized)) await saveAccounts(normalized);
        return normalized;
    } catch (error) {
        console.error("계정 읽기 오류:", error);
        throw error;
    }
}

async function saveAccounts(accounts) {
    const tempFile = `${ACCOUNT_FILE}.tmp`;
    await fs.promises.writeFile(tempFile, JSON.stringify(accounts, null, 2), "utf8");
    await fs.promises.rename(tempFile, ACCOUNT_FILE);
}

// 인증 계정(accounts.json)과 프로필(displayName/avatarUri)을 분리 저장합니다.
// 기존 계정·세션·메시지 파일은 삭제하거나 덮어쓰지 않습니다.
async function loadProfiles() {
    let profiles = [];
    if (fs.existsSync(PROFILE_FILE)) {
        try { profiles = JSON.parse(await fs.promises.readFile(PROFILE_FILE, "utf8")); } catch { profiles = []; }
    }
    if (!Array.isArray(profiles)) profiles = [];
    const known = new Set(profiles.map((profile) => normalizeEmail(profile.email || "")));
    let changed = false;
    for (const account of await loadAccounts()) {
        const email = normalizeEmail(account.email || "");
        if (!email || known.has(email)) continue;
        profiles.push({ email, displayName: account.displayName || "", ...(account.avatarUri ? { avatarUri: account.avatarUri } : {}), updatedAt: new Date().toISOString() });
        known.add(email);
        changed = true;
    }
    if (changed || !fs.existsSync(PROFILE_FILE)) await saveProfiles(profiles);
    return profiles;
}

async function saveProfiles(profiles) {
    const tempFile = `${PROFILE_FILE}.tmp`;
    await fs.promises.writeFile(tempFile, JSON.stringify(profiles, null, 2), "utf8");
    await fs.promises.rename(tempFile, PROFILE_FILE);
}

const publicProfile = (profile) => ({
    email: normalizeEmail(profile.email),
    displayName: profile.displayName || "",
    ...(profile.avatarUri ? { avatarUri: profile.avatarUri } : {}),
    ...(profile.updatedAt ? { updatedAt: profile.updatedAt } : {}),
});

async function serializeProfileForViewer(profile, email) {
    const safe = publicProfile(profile);
    if (safe.avatarUri) safe.avatarUri = await signMediaUrl(safe.avatarUri, email);
    return safe;
}

const publicAccount = ({ passwordSalt, passwordHash, ...account }) => account;
const normalizeEmail = (email) => email.trim().toLowerCase();

async function loadBlockedFans() {
    if (!fs.existsSync(BLOCKED_FANS_FILE)) return [];
    const value = JSON.parse(await fs.promises.readFile(BLOCKED_FANS_FILE, "utf8"));
    if (!Array.isArray(value)) return [];
    return Array.from(new Set(value.filter((email) => typeof email === "string").map(normalizeEmail)));
}

async function saveBlockedFans(blockedFans) {
    const tempFile = `${BLOCKED_FANS_FILE}.tmp`;
    await fs.promises.writeFile(tempFile, JSON.stringify(blockedFans, null, 2), "utf8");
    await fs.promises.rename(tempFile, BLOCKED_FANS_FILE);
}

async function loadServerConfig() {
    if (!fs.existsSync(SERVER_CONFIG_FILE)) return { baseUrl: null };
    const value = JSON.parse(await fs.promises.readFile(SERVER_CONFIG_FILE, "utf8"));
    return { baseUrl: typeof value.baseUrl === "string" ? value.baseUrl : null };
}

async function saveServerConfig(baseUrl) {
    const tempFile = `${SERVER_CONFIG_FILE}.tmp`;
    await fs.promises.writeFile(tempFile, JSON.stringify({ baseUrl }, null, 2), "utf8");
    await fs.promises.rename(tempFile, SERVER_CONFIG_FILE);
}

function canonicalServerOrigin(value) {
    if (typeof value !== "string" || !value || value.trim() !== value || /[\u0000-\u0020\u007f?#@\\]/.test(value)) return null;
    const match = value.match(/^(https?):\/\/([^/?#]+)(\/)?$/i);
    if (!match) return null;

    const authority = match[2];
    if (authority.includes("@") || authority.includes("[") || authority.includes("]") || authority.includes("\\")) return null;
    const portSeparator = authority.lastIndexOf(":");
    if (portSeparator >= 0 && authority.indexOf(":") !== portSeparator) return null;
    const rawHost = portSeparator < 0 ? authority : authority.slice(0, portSeparator);
    const rawPort = portSeparator < 0 ? "" : authority.slice(portSeparator + 1);
    if (!rawHost || (portSeparator >= 0 && (!/^[1-9]\d{0,4}$/.test(rawPort) || Number(rawPort) > 65535))) return null;

    let url;
    try { url = new URL(value); }
    catch { return null; }
    if (url.username || url.password || (url.pathname !== "" && url.pathname !== "/") || url.search || url.hash) return null;

    const hostname = url.hostname.toLowerCase();
    if (!hostname || hostname.endsWith(".") || hostname.includes(":")) return null;
    const isNumericHost = /^[\d.]+$/.test(rawHost);
    if (isNumericHost) {
        const octets = rawHost.split(".");
        if (!rawPort || octets.length !== 4 || octets.some((part) => !/^(0|[1-9]\d{0,2})$/.test(part) || Number(part) > 255) || net.isIP(rawHost) !== 4) return null;
        const [first, second, third, fourth] = octets.map(Number);
        if (first === 0 || first === 127 || first >= 224 || (first === 169 && second === 254) || (first === 255 && second === 255 && third === 255 && fourth === 255)) return null;
    } else {
        const labels = hostname.split(".");
        if (!hostname || hostname.length > 253 || labels.length < 2 || net.isIP(hostname) !== 0 || !labels.every((label) =>
            label.length >= 1 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label)
        ) || !/[a-z]/i.test(labels[labels.length - 1])) return null;
    }
    return url.origin;
}

const hashPassword = (password, salt) => crypto.scryptSync(password, salt, 64).toString("hex");
const passwordMatches = (password, account) => {
    if (!account?.passwordSalt || !account?.passwordHash) return false;
    const expected = Buffer.from(account.passwordHash, "hex");
    const actual = Buffer.from(hashPassword(password, account.passwordSalt), "hex");
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
};

const SESSION_LIFETIME_MS = 30 * 24 * 60 * 60 * 1000;
const ACTIVE_PRESENCE_WINDOW_MS = 45 * 1000;
const activeSessionLastSeen = new Map();
const MEDIA_LINK_LIFETIME_SECONDS = 10 * 60;
const hashSessionToken = (token) => crypto.createHash("sha256").update(token).digest("hex");

function touchSessionActivity(tokenHash, now = Date.now()) {
    activeSessionLastSeen.set(tokenHash, now);
    if (activeSessionLastSeen.size > 1000) {
        for (const [hash, lastSeenAt] of activeSessionLastSeen) {
            if (now - lastSeenAt > ACTIVE_PRESENCE_WINDOW_MS) activeSessionLastSeen.delete(hash);
        }
    }
}

async function loadSessions() {
    try {
        const value = JSON.parse(await fs.promises.readFile(SESSION_FILE, "utf8"));
        return Array.isArray(value) ? value.filter((session) => session && typeof session.tokenHash === "string" && typeof session.email === "string" && typeof session.expiresAt === "number") : [];
    } catch (error) {
        if (error.code === "ENOENT") return [];
        throw error;
    }
}

async function saveSessions(sessions) {
    const tempFile = `${SESSION_FILE}.tmp`;
    await fs.promises.writeFile(tempFile, JSON.stringify(sessions, null, 2), { encoding: "utf8", mode: 0o600 });
    await fs.promises.rename(tempFile, SESSION_FILE);
}

let offlineMessageCountQueue = Promise.resolve();
async function loadOfflineMessageCounts() {
    try {
        const value = JSON.parse(await fs.promises.readFile(OFFLINE_MESSAGE_COUNT_FILE, "utf8"));
        if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("오프라인 메시지 카운트 파일 형식이 올바르지 않습니다.");
        return value;
    } catch (error) {
        if (error.code === "ENOENT") return {};
        throw error;
    }
}
async function updateOfflineMessageCounts(update) {
    const operation = offlineMessageCountQueue.then(async () => {
        const counts = await loadOfflineMessageCounts();
        update(counts);
        const tempFile = `${OFFLINE_MESSAGE_COUNT_FILE}.${process.pid}.tmp`;
        await fs.promises.writeFile(tempFile, JSON.stringify(counts, null, 2), { encoding: "utf8", mode: 0o600 });
        await fs.promises.rename(tempFile, OFFLINE_MESSAGE_COUNT_FILE);
    });
    offlineMessageCountQueue = operation.catch(() => undefined);
    return operation;
}
async function readOfflineMessageCount(email) {
    await offlineMessageCountQueue.catch(() => undefined);
    const counts = await loadOfflineMessageCounts();
    const ids = counts[normalizeEmail(email)];
    return Array.isArray(ids) ? ids.filter((id) => typeof id === "string").length : 0;
}
async function recordOfflineArtistMessage(message) {
    if (!message || message.senderRole !== "artist" || typeof message.id !== "string") return;
    const fans = (await loadAccounts()).filter((account) => account.role === "fan" && typeof account.email === "string");
    const recipients = message.scope === "direct"
        ? fans.filter((account) => normalizeEmail(account.email) === normalizeEmail(message.recipientFanId || ""))
        : message.scope === "global" ? fans : [];
    if (!recipients.length) return;
    const now = Date.now();
    const activeSessions = new Set((await loadSessions())
        .filter((session) => {
            const lastSeenAt = activeSessionLastSeen.get(session.tokenHash);
            return session.expiresAt > now
                && typeof lastSeenAt === "number"
                && now >= lastSeenAt
                && now - lastSeenAt <= ACTIVE_PRESENCE_WINDOW_MS;
        })
        .map((session) => normalizeEmail(session.email)));
    const offlineEmails = recipients.map((account) => normalizeEmail(account.email)).filter((email) => !activeSessions.has(email));
    if (!offlineEmails.length) return;
    await updateOfflineMessageCounts((counts) => {
        for (const email of offlineEmails) {
            const ids = Array.isArray(counts[email]) ? counts[email].filter((id) => typeof id === "string") : [];
            if (!ids.includes(message.id)) counts[email] = [...ids, message.id];
        }
    });
}
async function clearOfflineArtistMessageCount(email) {
    await updateOfflineMessageCounts((counts) => { delete counts[normalizeEmail(email)]; });
}
async function issueSession(account) {
    const token = crypto.randomBytes(32).toString("base64url");
    const now = Date.now();
    const sessions = (await loadSessions()).filter((session) => session.expiresAt > now);
    const tokenHash = hashSessionToken(token);
    sessions.push({ tokenHash, email: normalizeEmail(account.email), expiresAt: now + SESSION_LIFETIME_MS });
    await saveSessions(sessions);
    touchSessionActivity(tokenHash, now);
    return token;
}

async function requireAuth(req, res, next) {
    try {
        const match = typeof req.headers.authorization === "string" && req.headers.authorization.match(/^Bearer ([A-Za-z0-9_-]{40,})$/);
        if (!match) return res.status(401).json({ error: "로그인 세션이 없거나 만료되었습니다. 다시 로그인해 주세요." });
        const tokenHash = hashSessionToken(match[1]);
        const session = (await loadSessions()).find((item) => item.tokenHash === tokenHash && item.expiresAt > Date.now());
        if (!session) return res.status(401).json({ error: "로그인 세션이 만료되었습니다. 다시 로그인해 주세요." });
        const account = (await loadAccounts()).find((item) => normalizeEmail(item.email) === normalizeEmail(session.email));
        if (!account) return res.status(401).json({ error: "계정을 찾을 수 없어 다시 로그인해야 합니다." });
        touchSessionActivity(tokenHash);
        req.auth = { account, email: normalizeEmail(account.email), role: account.role, tokenHash };
        return next();
    } catch (error) {
        console.error("세션 확인 오류:", error);
        return res.status(500).json({ error: "로그인 세션 확인 실패" });
    }
}

let mediaSigningKeyPromise;
async function getMediaSigningKey() {
    if (!mediaSigningKeyPromise) {
        mediaSigningKeyPromise = (async () => {
            try { return await fs.promises.readFile(MEDIA_SIGNING_KEY_FILE); }
            catch (error) {
                if (error.code !== "ENOENT") throw error;
                const generated = crypto.randomBytes(32);
                try { await fs.promises.writeFile(MEDIA_SIGNING_KEY_FILE, generated, { flag: "wx", mode: 0o600 }); return generated; }
                catch (writeError) { if (writeError.code === "EEXIST") return fs.promises.readFile(MEDIA_SIGNING_KEY_FILE); throw writeError; }
            }
        })();
    }
    return mediaSigningKeyPromise;
}

async function mediaSignature(pathname, email, expiresAt) {
    const key = await getMediaSigningKey();
    return crypto.createHmac("sha256", key).update(`${pathname}\n${normalizeEmail(email)}\n${expiresAt}`).digest("hex");
}

async function signMediaUrl(value, email) {
    if (typeof value !== "string" || !value) return value;
    const canonical = canonicalMediaUrl(value);
    let pathname;
    try { pathname = new URL(canonical, "http://media.local").pathname; } catch { return value; }
    if (!/^\/media\/(?:image|voice|video)\/[^/]+$/.test(pathname)) return value;
    const expiresAt = Math.floor(Date.now() / 1000) + MEDIA_LINK_LIFETIME_SECONDS;
    const signature = await mediaSignature(pathname, email, expiresAt);
    return `${pathname}?e=${expiresAt}&s=${signature}`;
}

function isMessageVisibleTo(message, account, blockedFans) {
    const email = normalizeEmail(account.email);
    if (account.role === "artist") return !(message.senderRole === "fan" && blockedFans.includes(normalizeEmail(message.senderId || "")));
    if (blockedFans.includes(email) && message.scope === "direct") return false;
    if (message.scope === "global") return true;
    return normalizeEmail(message.recipientFanId || "") === email
        || (message.senderRole === "fan" && normalizeEmail(message.senderId || "") === email);
}

function collectMessageMediaPaths(message) {
    const values = [message.imageUri, ...(Array.isArray(message.imageUris) ? message.imageUris : []), ...(Array.isArray(message.media) ? message.media.map((item) => item?.url) : [])];
    return new Set(values.filter((value) => typeof value === "string").map((value) => {
        try { return new URL(canonicalMediaUrl(value), "http://media.local").pathname; } catch { return ""; }
    }).filter(Boolean));
}

async function serializeMessageForViewer(message, email) {
    const normalized = normalizeMessageMediaPaths(message);
    return {
        ...normalized,
        ...(normalized.imageUri ? { imageUri: await signMediaUrl(normalized.imageUri, email) } : {}),
        ...(Array.isArray(normalized.imageUris) ? { imageUris: await Promise.all(normalized.imageUris.map((url) => signMediaUrl(url, email))) } : {}),
        ...(Array.isArray(normalized.media) ? { media: await Promise.all(normalized.media.map(async (item) => ({ ...item, url: await signMediaUrl(item.url, email) }))) } : {}),
    };
}

async function serializeAccountForViewer(account, email) {
    const safe = publicAccount(account);
    if (safe.avatarUri) safe.avatarUri = await signMediaUrl(safe.avatarUri, email);
    return safe;
}

async function resolveSignedMediaRequest(req) {
    const pathname = `/media/${req.params.folder}/${req.params.filename}`;
    if (!/^\/media\/(?:image|voice|video)\/[A-Za-z0-9._-]+$/.test(pathname)) return null;
    const expiresAt = Number(req.query.e);
    const signature = typeof req.query.s === "string" ? req.query.s : "";
    const now = Math.floor(Date.now() / 1000);
    if (!Number.isSafeInteger(expiresAt) || expiresAt < now || expiresAt > now + MEDIA_LINK_LIFETIME_SECONDS + 30 || !/^[a-f0-9]{64}$/i.test(signature)) return null;
    const accounts = await loadAccounts();
    const blockedFans = await loadBlockedFans();
    const messages = await loadMessages();
    const account = req.auth.account;
    const expected = Buffer.from(await mediaSignature(pathname, account.email, expiresAt), "hex");
    const received = Buffer.from(signature, "hex");
    if (!crypto.timingSafeEqual(expected, received)) return null;
    const profiles = await loadProfiles();
    const avatarReference = profiles.some((candidate) => candidate.avatarUri && new URL(canonicalMediaUrl(candidate.avatarUri), "http://media.local").pathname === pathname);
    const messageReference = messages.some((message) => isMessageVisibleTo(message, account, blockedFans) && collectMessageMediaPaths(message).has(pathname));
    return avatarReference || messageReference ? account : null;
}

async function signMessagesForViewer(messages, account, blockedFans) {
    return Promise.all(messages.filter((message) => isMessageVisibleTo(message, account, blockedFans)).map((message) => serializeMessageForViewer(message, account.email)));
}

async function createServerAccount({ email, password, displayName, role, avatarUri }) {
    const normalizedEmail = normalizeEmail(email);
    const accounts = await loadAccounts();
    if (accounts.some((account) => account.email === normalizedEmail)) {
        const error = new Error("이미 등록된 이메일입니다.");
        error.status = 409;
        throw error;
    }
    const passwordSalt = crypto.randomBytes(16).toString("hex");
    const account = {
        email: normalizedEmail,
        displayName: displayName.trim(),
        role,
        ...(typeof avatarUri === "string" && avatarUri ? { avatarUri: canonicalMediaUrl(avatarUri, "image") } : {}),
        passwordSalt,
        passwordHash: hashPassword(password, passwordSalt),
        createdAt: new Date().toISOString(),
    };
    await saveAccounts([...accounts, account]);
    return publicAccount(account);
}

// 파일 업로드 설정
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const selectedType = uploadMediaType(req, file);
        let targetDir;

        if (selectedType === "image") {
            targetDir = IMAGE_DIR;
        } else if (selectedType === "video") {
            targetDir = VIDEO_DIR;
        } else if (selectedType === "audio") {
            targetDir = VOICE_DIR;
        } else {
            return cb(new Error("지원하지 않는 파일 형식입니다."));
        }

        cb(null, targetDir);
    },

    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, crypto.randomUUID() + ext);
    }
});

// Multer 업로드 객체
const upload = multer({
    storage: storage,
    limits: {
        fileSize: 500 * 1024 * 1024
    }
});

// 미디어 업로드
app.post("/api/media/upload", requireAuth, upload.single("file"), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                error: "업로드 파일이 없습니다."
            });
        }

        const mimeType = req.file.mimetype;
        const mediaType = uploadMediaType(req, req.file);

        if (!mediaType) {
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: "지원하지 않는 파일 형식입니다." });
        }

        const id = path.parse(req.file.filename).name;

        const folder = folderForType(mediaType);
        const storedInExpectedFolder = path.dirname(req.file.path) === MEDIA_FOLDERS[mediaType];
        if (!storedInExpectedFolder) {
            return res.status(500).json({ error: "업로드 유형과 PC 저장 폴더가 일치하지 않습니다." });
        }

        return res.json({
            id: id,
            url: `/media/${folder}/${req.file.filename}`,
            mediaType: mediaType,
            mimeType: mimeType,
            fileSize: req.file.size
        });

    } catch (error) {
        console.error("Upload error:", error);

        return res.status(500).json({
            error: "파일 업로드 실패"
        });
    }
});

// 미디어 파일은 계정별 단기 서명 URL로만 제공합니다. 폴더 정적 공개는 사용하지 않습니다.
app.get("/media/:folder/:filename", requireAuth, async (req, res) => {
    try {
        const account = await resolveSignedMediaRequest(req);
        if (!account) return res.status(403).json({ error: "미디어 접근 권한이 없거나 링크가 만료되었습니다." });
        const folder = req.params.folder === "voice" ? VOICE_DIR : req.params.folder === "image" ? IMAGE_DIR : req.params.folder === "video" ? VIDEO_DIR : null;
        const filePath = folder ? path.resolve(folder, req.params.filename) : "";
        if (!folder || path.dirname(filePath) !== path.resolve(folder) || !fs.existsSync(filePath)) return res.status(404).json({ error: "미디어 파일을 찾을 수 없습니다." });
        res.setHeader("Cache-Control", "private, no-store");
        return res.sendFile(filePath);
    } catch (error) {
        console.error("미디어 권한 확인 오류:", error);
        return res.status(500).json({ error: "미디어 권한 확인 실패" });
    }
});

// 메시지 목록 조회
app.get("/api/messages/offline-count", requireAuth, async (req, res) => {
    try {
        if (req.auth.role !== "fan") return res.status(403).json({ error: "팬 계정만 오프라인 메시지 수를 조회할 수 있습니다." });
        const count = await readOfflineMessageCount(req.auth.email);
        res.setHeader("Cache-Control", "private, no-store, max-age=0");
        return res.json({ count });
    } catch (error) {
        console.error("오프라인 메시지 수 조회 오류:", error);
        return res.status(500).json({ error: "오프라인 메시지 수 조회 실패" });
    }
});
app.get("/api/messages", requireAuth, async (req, res) => {
    try {
        const messages = await loadMessages();
        const blockedFans = await loadBlockedFans();
        res.setHeader("Cache-Control", "private, no-store");
        res.json({ messages: await signMessagesForViewer(messages, req.auth.account, blockedFans), nextCursor: messageCursor(messages) });

    } catch (error) {
        console.error("메시지 조회 오류:", error);
        res.status(500).json({
            error: "메시지 조회 실패"
        });
    }
});

// 최초 전체 조회 이후에는 새로 저장된 메시지만 조회합니다.
app.get("/api/messages/updates", requireAuth, async (req, res) => {
    try {
        const after = req.query.after === undefined ? 0 : Number(req.query.after);
        if (!Number.isSafeInteger(after) || after < 0) return res.status(400).json({ error: "메시지 커서가 올바르지 않습니다." });
        const messages = await loadMessages();
        const blockedFans = await loadBlockedFans();
        const freshMessages = messages.filter((message) => Number.isSafeInteger(message.serverSequence) && message.serverSequence > after);
        res.setHeader("Cache-Control", "private, no-store");
        res.json({ messages: await signMessagesForViewer(freshMessages, req.auth.account, blockedFans), nextCursor: messageCursor(messages) });
    } catch (error) {
        console.error("새 메시지 조회 오류:", error);
        res.status(500).json({ error: "새 메시지 조회 실패" });
    }
});

// 클라이언트는 로그인 세션이 일치할 때만 요청하며, 서버는 계정·메시지 수신 권한을 다시 검증합니다.
app.post("/api/messages/read", requireAuth, async (req, res) => {
    try {
        const { messageIds } = req.body || {};
        if (!Array.isArray(messageIds) || messageIds.length > 500 || messageIds.some((id) => typeof id !== "string")) {
            return res.status(400).json({ error: "읽음 처리 정보가 올바르지 않습니다." });
        }

        const reader = req.auth.account;
        const normalizedReaderId = req.auth.email;

        const blockedFans = await loadBlockedFans();
        const messages = await loadMessages();
        const requestedIds = new Set(messageIds);
        let changed = false;
        const updatedMessages = messages.map((message) => {
            if (!requestedIds.has(message.id)) return message;
            const isEligible = reader.role === "artist"
                ? message.senderRole === "fan" && !blockedFans.includes(normalizeEmail(message.senderId || ""))
                : message.senderRole === "artist"
                    && message.scope === "direct"
                    && normalizeEmail(message.recipientFanId || "") === normalizedReaderId
                    && !blockedFans.includes(normalizedReaderId);
            if (!isEligible) return message;

            const readBy = Array.isArray(message.readBy) ? message.readBy : [];
            if (readBy.some((email) => typeof email === "string" && normalizeEmail(email) === normalizedReaderId)) return message;
            changed = true;
            return { ...message, readBy: [...readBy, normalizedReaderId] };
        });

        if (changed) await saveMessages(updatedMessages);
        res.json({ ok: true, updatedIds: messageIds.filter((id) => updatedMessages.some((message) => message.id === id && (message.readBy ?? []).some((readerId) => normalizeEmail(readerId) === normalizedReaderId))) });
    } catch (error) {
        console.error("메시지 읽음 상태 저장 오류:", error);
        res.status(500).json({ error: "읽음 상태 저장 실패" });
    }
});

// 개인 대화 화면용 읽음 상태만 조회 (메시지 본문/첨부는 반환하지 않음)
app.post("/api/messages/read-status", requireAuth, async (req, res) => {
    try {
        const { messageIds } = req.body || {};
        if (!Array.isArray(messageIds) || messageIds.length > 500
            || messageIds.some((id) => typeof id !== "string" || id.length > 120)) {
            return res.status(400).json({ error: "읽음 상태 조회 대상이 올바르지 않습니다." });
        }

        const requestedIds = new Set(messageIds);
        const messages = await loadMessages();
        const readStatuses = messages
            .filter((message) => requestedIds.has(message.id)
                && message.scope === "direct"
                && message.senderRole === req.auth.role
                && normalizeEmail(message.senderId || "") === req.auth.email)
            .map((message) => ({
                messageId: message.id,
                readBy: Array.isArray(message.readBy)
                    ? message.readBy.filter((readerId) => typeof readerId === "string").map(normalizeEmail)
                    : [],
            }));

        res.setHeader("Cache-Control", "private, no-store, max-age=0");
        res.json({ readStatuses });
    } catch (error) {
        console.error("메시지 읽음 상태 조회 오류:", error);
        res.status(500).json({ error: "읽음 상태 조회 실패" });
    }
});

// 메시지 저장
app.post("/api/messages", requireAuth, async (req, res) => {
    try {
        const body = req.body;
        if (!body || typeof body.id !== "string" || body.id.length > 120 || !["global", "direct"].includes(body.scope)
            || body.senderRole !== req.auth.role || normalizeEmail(body.senderId || "") !== req.auth.email
            || typeof body.senderName !== "string" || typeof body.createdAt !== "string"
            || (body.text !== undefined && (typeof body.text !== "string" || body.text.length > 20000))) {
            return res.status(400).json({
                error: "메시지 내용 또는 발신 계정 정보가 올바르지 않습니다."
            });
        }

        const blockedFans = await loadBlockedFans();
        if (req.auth.role === "fan" && blockedFans.includes(req.auth.email)) {
            return res.status(403).json({ error: "차단된 계정은 메시지를 보낼 수 없습니다." });
        }
        if (body.scope === "global" && req.auth.role !== "artist" && req.auth.role !== "fan") return res.status(403).json({ error: "이 대화방에 메시지를 보낼 권한이 없습니다." });
        if (body.scope === "direct") {
            if (typeof body.recipientFanId !== "string") return res.status(400).json({ error: "개인 메시지 수신자가 없습니다." });
            if (req.auth.role === "fan" && normalizeEmail(body.recipientFanId) !== req.auth.email) return res.status(403).json({ error: "다른 팬의 개인 대화방에 메시지를 보낼 수 없습니다." });
            if (req.auth.role === "artist" && !(await loadAccounts()).some((account) => account.role === "fan" && normalizeEmail(account.email) === normalizeEmail(body.recipientFanId))) return res.status(403).json({ error: "등록된 팬만 개인 메시지를 받을 수 있습니다." });
        } else if (body.recipientFanId) return res.status(400).json({ error: "전체 메시지에는 개인 수신자를 지정할 수 없습니다." });

        const messages = await loadMessages();

        let storedMessage = messages.find((message) => message.id === body.id);
        const isNewMessage = !storedMessage;
        if (!storedMessage) {
            const serverSequence = await issueMessageSequence(messages);
            storedMessage = normalizeMessageMediaPaths({ ...body, senderId: req.auth.email, senderRole: req.auth.role, readBy: [], serverSequence });
            messages.push(storedMessage);
            await saveMessages(messages);
        }
        if (req.auth.role === "artist" && isNewMessage) {
            try { await recordOfflineArtistMessage(storedMessage); }
            catch (counterError) { console.error("오프라인 메시지 카운트 기록 오류:", counterError); }
        } else if (req.auth.role === "fan") {
            try { await clearOfflineArtistMessageCount(req.auth.email); }
            catch (counterError) { console.error("오프라인 메시지 카운트 초기화 오류:", counterError); }
        }
        const visibleStoredMessage = (await signMessagesForViewer([storedMessage], req.auth.account, blockedFans))[0];
        res.status(201).json({ ok: true, message: visibleStoredMessage, nextCursor: messageCursor(messages) });

    } catch (error) {
        console.error("메시지 저장 오류:", error);
        res.status(500).json({
            error: "메시지 저장 실패"
        });
    }
});

// 계정과 프로필은 같은 accounts.json 레코드에 저장합니다.
app.get("/api/accounts", requireAuth, async (req, res) => {
    try {
        const accounts = await loadAccounts();
        res.json({ accounts: await Promise.all(accounts.map((account) => serializeAccountForViewer(account, req.auth.email))) });
    } catch (error) {
        console.error("계정 목록 조회 오류:", error);
        res.status(500).json({ error: "계정 목록 조회 실패" });
    }
});

// 프로필은 인증 계정 레코드와 분리된 profiles.json에서만 조회·저장합니다.
app.get("/api/profiles", requireAuth, async (req, res) => {
    try {
        const profiles = await loadProfiles();
        res.json({ profiles: await Promise.all(profiles.map((profile) => serializeProfileForViewer(profile, req.auth.email))) });
    } catch (error) {
        console.error("프로필 목록 조회 오류:", error);
        res.status(500).json({ error: "프로필 목록 조회 실패" });
    }
});

app.get("/api/profiles/:email", requireAuth, async (req, res) => {
    try {
        const profiles = await loadProfiles();
        const profile = profiles.find((item) => normalizeEmail(item.email) === normalizeEmail(req.params.email));
        if (!profile) return res.status(404).json({ error: "프로필을 찾을 수 없습니다." });
        res.json({ profile: await serializeProfileForViewer(profile, req.auth.email) });
    } catch (error) {
        console.error("프로필 조회 오류:", error);
        res.status(500).json({ error: "프로필 조회 실패" });
    }
});

app.put("/api/profiles/:email", requireAuth, async (req, res) => {
    try {
        const email = normalizeEmail(req.params.email);
        if (email !== req.auth.email) return res.status(403).json({ error: "다른 계정의 프로필을 수정할 수 없습니다." });
        const { displayName, avatarUri } = req.body || {};
        if (typeof displayName !== "string" || !displayName.trim() || (avatarUri !== undefined && avatarUri !== null && (typeof avatarUri !== "string" || avatarUri.length > 2048))) {
            return res.status(400).json({ error: "프로필 정보가 올바르지 않습니다." });
        }
        const profiles = await loadProfiles();
        const index = profiles.findIndex((item) => normalizeEmail(item.email) === email);
        const previous = index >= 0 ? profiles[index] : { email };
        const updated = { ...previous, email, displayName: displayName.trim(), updatedAt: new Date().toISOString() };
        if (avatarUri === null) delete updated.avatarUri;
        else if (typeof avatarUri === "string") updated.avatarUri = canonicalMediaUrl(avatarUri, "image");
        if (index >= 0) profiles[index] = updated;
        else profiles.push(updated);
        await saveProfiles(profiles);
        res.json({ profile: await serializeProfileForViewer(updated, req.auth.email) });
    } catch (error) {
        console.error("프로필 저장 오류:", error);
        res.status(500).json({ error: "프로필 저장 실패" });
    }
});

app.get("/api/moderation/blocked-fans", requireAuth, async (req, res) => {
    try {
        res.json({ blockedFans: await loadBlockedFans() });
    } catch (error) {
        console.error("차단 상태 조회 오류:", error);
        res.status(500).json({ error: "차단 상태 조회 실패" });
    }
});

app.put("/api/moderation/blocked-fans", requireAuth, async (req, res) => {
    try {
        const { blockedFans: requestedBlockedFans } = req.body || {};
        if (!Array.isArray(requestedBlockedFans)) {
            return res.status(400).json({ error: "차단 상태 변경 정보가 올바르지 않습니다." });
        }
        const accounts = await loadAccounts();
        const actor = req.auth.account;
        if (!actor) return res.status(403).json({ error: "아티스트 계정만 차단 상태를 변경할 수 있습니다." });
        if (actor.role !== "artist") return res.status(403).json({ error: "아티스트 계정만 차단 상태를 변경할 수 있습니다." });

        const fanEmails = new Set(accounts.filter((account) => account.role === "fan").map((account) => normalizeEmail(account.email)));
        const blockedFans = Array.from(new Set(requestedBlockedFans
            .filter((email) => typeof email === "string")
            .map(normalizeEmail)
            .filter((email) => fanEmails.has(email))));
        await saveBlockedFans(blockedFans);
        res.json({ blockedFans });
    } catch (error) {
        console.error("차단 상태 저장 오류:", error);
        res.status(500).json({ error: "차단 상태 저장 실패" });
    }
});

app.get("/api/server-config", async (req, res) => {
    try {
        res.json(await loadServerConfig());
    } catch (error) {
        console.error("서버 설정 조회 오류:", error);
        res.status(500).json({ error: "서버 설정 조회 실패" });
    }
});

app.put("/api/server-config", requireAuth, async (req, res) => {
    try {
        const { baseUrl } = req.body || {};
        const actor = req.auth.account;
        if (!actor) return res.status(403).json({ error: "아티스트 계정만 서버 주소를 변경할 수 있습니다." });
        if (actor.role !== "artist") return res.status(403).json({ error: "아티스트 계정만 서버 주소를 변경할 수 있습니다." });

        const canonicalBaseUrl = canonicalServerOrigin(baseUrl);
        if (!canonicalBaseUrl) return res.status(400).json({ error: "IPv4는 포트를 포함한 http://192.168.0.10:8787 형식, 도메인은 https://api.example.com 형식이어야 하며 API 경로·쿼리·인증정보는 포함할 수 없습니다." });
        await saveServerConfig(canonicalBaseUrl);
        res.json({ baseUrl: canonicalBaseUrl });
    } catch (error) {
        console.error("서버 설정 저장 오류:", error);
        res.status(500).json({ error: "서버 설정 저장 실패" });
    }
});

app.post("/api/accounts/register", async (req, res) => {
    try {
        const { email, password, displayName, role, avatarUri } = req.body || {};
        if (typeof email !== "string" || !/^\S+@\S+\.\S+$/.test(email.trim()) || typeof password !== "string" || password.length < 8 || typeof displayName !== "string" || !displayName.trim() || !["artist", "fan"].includes(role)) {
            return res.status(400).json({ error: "계정 정보가 올바르지 않습니다." });
        }
        if (role === "artist" && (await loadAccounts()).some((account) => account.role === "artist")) {
            return res.status(403).json({ error: "이 서버에 아티스트 계정이 이미 등록되어 있습니다." });
        }
        const account = await createServerAccount({ email, password, displayName, role, avatarUri });
        res.status(201).json({ account, token: await issueSession(account) });
    } catch (error) {
        if (error.status === 409) return res.status(409).json({ error: error.message });
        console.error("계정 생성 오류:", error);
        res.status(500).json({ error: "계정 생성 실패" });
    }
});

// 기존 기기 로컬 계정은 해당 기기에서 비밀번호 검증 후 한 번만 서버 계정으로 이전합니다.
app.post("/api/accounts/migrate", async (req, res) => {
    try {
        const { email, password, displayName, role, avatarUri } = req.body || {};
        if (typeof email !== "string" || typeof password !== "string" || password.length < 8 || typeof displayName !== "string" || !displayName.trim() || !["artist", "fan"].includes(role)) {
            return res.status(400).json({ error: "기존 계정 정보가 올바르지 않습니다." });
        }
        let legacyProfile = null;
        try {
            const legacyProfiles = JSON.parse(await fs.promises.readFile(LEGACY_MEMBER_FILE, "utf8"));
            legacyProfile = legacyProfiles.find((profile) => normalizeEmail(profile.id || profile.email || "") === normalizeEmail(email));
        } catch { /* old patch data may not exist */ }
        const account = await createServerAccount({
            email,
            password,
            displayName: legacyProfile?.displayName || displayName,
            role,
            avatarUri: legacyProfile?.avatarUri || avatarUri,
        });
        res.status(201).json({ account, token: await issueSession(account) });
    } catch (error) {
        if (error.status === 409) return res.status(409).json({ error: "이미 서버에 등록된 계정입니다. 로그인해 주세요." });
        console.error("기존 계정 이전 오류:", error);
        res.status(500).json({ error: "기존 계정 이전 실패" });
    }
});

app.post("/api/accounts/login", async (req, res) => {
    try {
        const { email, password } = req.body || {};
        if (typeof email !== "string" || typeof password !== "string") return res.status(400).json({ error: "이메일과 비밀번호를 입력해 주세요." });
        const account = (await loadAccounts()).find((item) => item.email === normalizeEmail(email));
        if (!account) return res.status(404).json({ error: "등록된 계정이 없습니다. 먼저 가입해 주세요." });
        if (!passwordMatches(password, account)) return res.status(401).json({ error: "이메일 또는 비밀번호가 올바르지 않습니다." });
        res.json({ account: publicAccount(account), token: await issueSession(account) });
    } catch (error) {
        console.error("로그인 오류:", error);
        res.status(500).json({ error: "로그인 실패" });
    }
});

app.post("/api/auth/logout", requireAuth, async (req, res) => {
    try {
        await saveSessions((await loadSessions()).filter((session) => session.tokenHash !== req.auth.tokenHash));
        activeSessionLastSeen.delete(req.auth.tokenHash);
        return res.json({ ok: true });
    } catch (error) {
        console.error("로그아웃 세션 폐기 오류:", error);
        return res.status(500).json({ error: "로그아웃 세션 폐기 실패" });
    }
});

app.get("/api/accounts/:email", requireAuth, async (req, res) => {
    try {
        const account = (await loadAccounts()).find((item) => item.email === normalizeEmail(req.params.email));
        if (!account) return res.status(404).json({ error: "계정을 찾을 수 없습니다." });
        res.json({ account: await serializeAccountForViewer(account, req.auth.email) });
    } catch (error) {
        console.error("계정 조회 오류:", error);
        res.status(500).json({ error: "계정 조회 실패" });
    }
});

app.put("/api/accounts/:email/profile", requireAuth, async (req, res) => {
    try {
        const email = normalizeEmail(req.params.email);
        if (email !== req.auth.email) return res.status(403).json({ error: "다른 계정의 프로필을 수정할 수 없습니다." });
        const { displayName, avatarUri } = req.body || {};
        if (typeof displayName !== "string" || !displayName.trim() || (avatarUri !== undefined && avatarUri !== null && (typeof avatarUri !== "string" || avatarUri.length > 2048))) {
            return res.status(400).json({ error: "프로필 정보가 올바르지 않습니다." });
        }
        const accounts = await loadAccounts();
        const index = accounts.findIndex((item) => item.email === email);
        if (index < 0) return res.status(404).json({ error: "계정을 찾을 수 없습니다." });
        const updated = { ...accounts[index], displayName: displayName.trim() };
        if (avatarUri === null) delete updated.avatarUri;
        else if (typeof avatarUri === "string") updated.avatarUri = canonicalMediaUrl(avatarUri, "image");
        accounts[index] = updated;
        await saveAccounts(accounts);
        res.json({ account: await serializeAccountForViewer(updated, req.auth.email) });
    } catch (error) {
        console.error("프로필 저장 오류:", error);
        res.status(500).json({ error: "프로필 저장 실패" });
    }
});

app.put("/api/accounts/:email/password", requireAuth, async (req, res) => {
    try {
        const email = normalizeEmail(req.params.email);
        if (email !== req.auth.email) return res.status(403).json({ error: "다른 계정의 비밀번호를 변경할 수 없습니다." });
        const { currentPassword, nextPassword } = req.body || {};
        if (typeof currentPassword !== "string" || typeof nextPassword !== "string" || nextPassword.length < 8) {
            return res.status(400).json({ error: "새 비밀번호는 8자 이상이어야 합니다." });
        }
        const accounts = await loadAccounts();
        const account = accounts.find((item) => item.email === email);
        if (!account) return res.status(404).json({ error: "계정을 찾을 수 없습니다." });
        if (!passwordMatches(currentPassword, account)) return res.status(401).json({ error: "현재 비밀번호가 올바르지 않습니다." });
        account.passwordSalt = crypto.randomBytes(16).toString("hex");
        account.passwordHash = hashPassword(nextPassword, account.passwordSalt);
        await saveAccounts(accounts);
        res.json({ ok: true });
    } catch (error) {
        console.error("비밀번호 변경 오류:", error);
        res.status(500).json({ error: "비밀번호 변경 실패" });
    }
});

// 서버 상태 확인
app.get("/health", (req, res) => {
    res.json({
        status: "ok",
        mediaRoot: path.resolve(MEDIA_DIR),
        mediaFolders: {
            image: fs.existsSync(IMAGE_DIR),
            voice: fs.existsSync(VOICE_DIR),
            video: fs.existsSync(VIDEO_DIR)
        }
    });
});

// 시작할 때 메시지·프로필 URL을 실제 media 하위 폴더 경로로 한 번 정규화합니다.
(async () => {
    try {
        await loadMessages();
        await loadAccounts();
    } catch (error) {
        console.error("미디어 경로 초기화 오류:", error);
    }
    app.listen(PORT, "0.0.0.0", () => {
        console.log(`Media server running on port ${PORT}; media root: ${path.resolve(MEDIA_DIR)}`);
    });
})();
